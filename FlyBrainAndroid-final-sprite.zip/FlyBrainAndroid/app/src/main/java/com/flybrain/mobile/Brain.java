package com.flybrain.mobile;

import java.util.Random;

public final class Brain {
    static final class LIF {
        float v, rate; final float tau, thr;
        LIF(float tau, float thr){this.tau=tau;this.thr=thr;}
        boolean step(float input,float dt){
            v += dt*((-v + Math.max(0f,input))/tau);
            boolean spike=v>=thr;
            if(spike) v=0f;
            rate = rate*0.93f + (spike?0.07f:0f);
            return spike;
        }
    }
    private final LIF t1=new LIF(.10f,.78f), t2=new LIF(.12f,.78f), t45=new LIF(.12f,.72f), lc4=new LIF(.10f,.68f), gf=new LIF(.08f,.62f);
    private final LIF orn=new LIF(.20f,.74f), pn=new LIF(.18f,.74f), kc=new LIF(.30f,.88f), mbon=new LIF(.24f,.82f);
    private final LIF dnTurn=new LIF(.15f,.74f), dnForward=new LIF(.15f,.74f), dnEscape=new LIF(.10f,.62f);
    private final Random rnd=new Random();
    public float memory=.35f, curiosity=.45f, energy=.7f, escape, forward, turn;
    public int spikes;

    public void step(float motion, float touchReward, float battery, float circadian, float dt){
        spikes=0;
        float looming=Math.min(1f,Math.max(0f,motion));
        if(t1.step(.25f+looming*.7f,dt))spikes++;
        if(t2.step(t1.rate*1.7f+looming*.8f,dt))spikes++;
        if(t45.step(t2.rate*1.6f+looming*1.5f,dt))spikes++;
        if(lc4.step(t45.rate*2.1f+looming*1.4f,dt))spikes++;
        if(gf.step(lc4.rate*2.4f+looming*1.1f,dt))spikes++;

        float odor=.15f+touchReward*.8f+battery*.1f;
        if(orn.step(odor*1.4f,dt))spikes++;
        if(pn.step(orn.rate*1.8f,dt))spikes++;
        if(kc.step(pn.rate*(1.1f+memory),dt))spikes++;
        if(mbon.step(kc.rate*(.85f+energy),dt))spikes++;

        if(dnEscape.step(gf.rate*3.0f,dt))spikes++;
        if(dnForward.step(.18f+mbon.rate*(.8f+curiosity)+circadian*.1f,dt))spikes++;
        if(dnTurn.step(.14f+rnd.nextFloat()*.18f+curiosity*.15f,dt))spikes++;
        escape=dnEscape.rate; forward=dnForward.rate; turn=dnTurn.rate;

        memory=clamp(memory + touchReward*kc.rate*.003f - looming*.0005f);
        curiosity=clamp(curiosity + touchReward*.0008f + (rnd.nextFloat()-.5f)*.00005f);
        energy=clamp(energy + battery*.00008f - .00004f);
    }
    public void develop(float elapsedHours){
        curiosity=clamp(curiosity + elapsedHours*.0008f);
        memory=clamp(memory + elapsedHours*.0003f);
    }
    static float clamp(float x){return Math.max(0f,Math.min(1f,x));}
}
