package com.flybrain.mobile;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.*;
import android.os.*;
import android.view.*;
import java.util.*;

public class FlyOverlayService extends Service implements SensorEventListener {
    private WindowManager wm; private FlyView view; private WindowManager.LayoutParams lp;
    private final Handler h=new Handler(Looper.getMainLooper()); private final Brain brain=new Brain();
    private SensorManager sm; private float shake=0f, touchReward=0f, battery=.5f; private long last=0, bornMs;
    private float vx=2.1f,vy=1.3f; private final Random rnd=new Random();

    @Override public void onCreate(){super.onCreate();
        createChannel(); startForeground(11,notification());
        wm=(WindowManager)getSystemService(WINDOW_SERVICE); sm=(SensorManager)getSystemService(SENSOR_SERVICE);
        Sensor a=sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER); if(a!=null)sm.registerListener(this,a,SensorManager.SENSOR_DELAY_GAME);
        Intent bi=registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED)); if(bi!=null){int l=bi.getIntExtra("level",50),s=bi.getIntExtra("scale",100);battery=s>0?(float)l/s:.5f;}
        android.content.SharedPreferences p=getSharedPreferences("brain",MODE_PRIVATE); brain.memory=p.getFloat("memory",.35f);brain.curiosity=p.getFloat("curiosity",.45f);brain.energy=p.getFloat("energy",.7f);bornMs=p.getLong("born",System.currentTimeMillis()); if(!p.contains("born")){bornMs=System.currentTimeMillis();p.edit().putLong("born",bornMs).apply();}
        addFly(); last=System.nanoTime(); h.post(loop);
    }
    private void addFly(){
        view=new FlyView(this);
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        lp=new WindowManager.LayoutParams(112,112,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.START;lp.x=120;lp.y=300;wm.addView(view,lp);
    }
    private final Runnable loop=new Runnable(){public void run(){
        long now=System.nanoTime();float dt=Math.min(.05f,(now-last)/1_000_000_000f);last=now;
        Calendar c=Calendar.getInstance();float circ=(float)(.5+.5*Math.cos((c.get(Calendar.HOUR_OF_DAY)-14)/24.0*Math.PI*2));
        brain.step(Math.min(1f,shake/8f),touchReward,battery,circ,dt);shake*=.86f;touchReward*=.90f;
        if(brain.escape>.12f){vx+=(rnd.nextFloat()-.5f)*12f;vy+=(rnd.nextFloat()-.5f)*12f;}
        else {vx+=(rnd.nextFloat()-.5f)*.6f+(brain.turn-.05f)*.4f;vy+=(rnd.nextFloat()-.5f)*.6f;}
        float speed=(2f+brain.forward*18f+brain.escape*30f)*(0.7f+brain.energy*.6f);float mag=(float)Math.hypot(vx,vy);if(mag>speed){vx=vx/mag*speed;vy=vy/mag*speed;}
        lp.x+=(int)vx;lp.y+=(int)vy;
        Point sz=new Point();wm.getDefaultDisplay().getSize(sz);int maxX=Math.max(0,sz.x-lp.width),maxY=Math.max(0,sz.y-lp.height-80);
        if(lp.x<0){lp.x=0;vx=Math.abs(vx);}if(lp.x>maxX){lp.x=maxX;vx=-Math.abs(vx);}if(lp.y<0){lp.y=0;vy=Math.abs(vy);}if(lp.y>maxY){lp.y=maxY;vy=-Math.abs(vy);}
        try{wm.updateViewLayout(view,lp);}catch(Exception ignored){} view.invalidate();
        h.postDelayed(this,33);
    }};
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){h.removeCallbacks(loop);if(sm!=null)sm.unregisterListener(this);if(view!=null)try{wm.removeView(view);}catch(Exception ignored){}getSharedPreferences("brain",MODE_PRIVATE).edit().putFloat("memory",brain.memory).putFloat("curiosity",brain.curiosity).putFloat("energy",brain.energy).apply();super.onDestroy();}
    @Override public void onSensorChanged(SensorEvent e){if(e.sensor.getType()==Sensor.TYPE_ACCELEROMETER){float m=(float)Math.sqrt(e.values[0]*e.values[0]+e.values[1]*e.values[1]+e.values[2]*e.values[2]);shake=Math.max(shake,Math.abs(m-9.81f));vx+=e.values[0]*-.02f;vy+=e.values[1]*.02f;}}
    @Override public void onAccuracyChanged(Sensor s,int a){}
    @Override public android.os.IBinder onBind(Intent i){return null;}

    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel("flybrain","Муха",NotificationManager.IMPORTANCE_LOW);ch.setDescription("Муха живёт поверх экрана");getSystemService(NotificationManager.class).createNotificationChannel(ch);}}
    private Notification notification(){Intent i=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);return new Notification.Builder(this,"flybrain").setContentTitle("🪰 Муха живёт").setContentText("Mini Fly Brain активен").setSmallIcon(android.R.drawable.ic_menu_compass).setContentIntent(pi).setOngoing(true).build();}

    private class FlyView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        android.graphics.Bitmap flyBitmap;
        long down;

        FlyView(Context c) {
            super(c);
            setBackgroundColor(Color.TRANSPARENT);
            flyBitmap = android.graphics.BitmapFactory.decodeResource(
                getResources(),
                com.flybrain.mobile.R.drawable.fly_sprite
            );
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);

            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;

            // Keep exactly the same overlay size as before: 112x112.
            // The realistic fly sprite is drawn inside it with a small margin.
            float spriteSize = Math.min(getWidth(), getHeight()) * 0.92f;

            float angle = (float) Math.toDegrees(Math.atan2(vy, vx));
            float speed = Math.min(1f, (float)Math.hypot(vx, vy) / 12f);
            float t = android.os.SystemClock.uptimeMillis() / 1000f;

            // Tiny natural movement so the sprite feels alive without changing its size.
            float bob = (float)Math.sin(t * (5f + speed * 7f)) * (0.8f + speed * 1.4f);
            float twitch = (float)Math.sin(t * 8.5f) * 1.8f * speed;

            c.save();
            c.translate(cx, cy + bob);
            c.rotate(angle + twitch);

            android.graphics.RectF dst = new android.graphics.RectF(
                -spriteSize / 2f,
                -spriteSize / 2f,
                 spriteSize / 2f,
                 spriteSize / 2f
            );

            c.drawBitmap(flyBitmap, null, dst, p);

            // Subtle red alert ring only during strong escape response.
            if (brain.escape > .18f) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2f);
                p.setColor(Color.argb(120, 255, 70, 70));
                c.drawOval(
                    -spriteSize * .42f, -spriteSize * .42f,
                     spriteSize * .42f,  spriteSize * .42f,
                    p
                );
                p.setStyle(Paint.Style.FILL);
            }

            c.restore();
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                down = System.currentTimeMillis();
                touchReward = 1f;
                vx += (rnd.nextFloat() - .5f) * 8;
                vy += (rnd.nextFloat() - .5f) * 8;

                try {
                    ((android.os.Vibrator)getSystemService(VIBRATOR_SERVICE))
                        .vibrate(android.os.VibrationEffect.createOneShot(24, 70));
                } catch (Exception ignored) {}

                return true;
            }
            return true;
        }
    }

}