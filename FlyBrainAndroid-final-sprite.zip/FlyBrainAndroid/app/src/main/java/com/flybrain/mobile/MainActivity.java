package com.flybrain.mobile;

import android.app.*;
import android.os.*;
import android.provider.Settings;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    private TextView status;
    @Override public void onCreate(Bundle b){super.onCreate(b); buildUi();}
    @Override protected void onResume(){super.onResume(); refresh();}

    private void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(40,60,40,40); root.setBackgroundColor(Color.rgb(9,12,16));
        TextView title=t("🪰 Муха — Mini Fly Brain",28,true); root.addView(title);
        TextView info=t("Мини-мозг на LIF-нейронах. Муха живёт поверх главного экрана, учится на касаниях, реагирует на тряску/наклон, заряд и время суток. Личные файлы, сообщения и фото не читает.",16,false); info.setPadding(0,24,0,24); root.addView(info);
        status=t("",16,true); root.addView(status);
        Button permission=new Button(this); permission.setText("1. Разрешить поверх других приложений"); permission.setOnClickListener(v->{Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())); startActivity(i);}); root.addView(permission);
        Button start=new Button(this); start.setText("2. Выпустить муху на экран"); start.setOnClickListener(v->startFly()); root.addView(start);
        Button stop=new Button(this); stop.setText("Остановить муху"); stop.setOnClickListener(v->stopService(new Intent(this,FlyOverlayService.class))); root.addView(stop);
        TextView note=t("Коснись мухи — она запомнит контакт как награду. Резко встряхни телефон — включится цепь побега. Состояние мозга сохраняется между запусками.",14,false); note.setPadding(0,24,0,0); root.addView(note);
        setContentView(root);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},7);
    }
    private TextView t(String s,int sp,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(Color.rgb(243,247,251));if(bold)v.setTypeface(null,1);return v;}
    private void refresh(){status.setText(Settings.canDrawOverlays(this)?"✓ Разрешение на муху поверх экрана включено":"Нужно разрешение ‘поверх других приложений’");}
    private void startFly(){
        if(!Settings.canDrawOverlays(this)){Toast.makeText(this,"Сначала дай разрешение поверх других приложений",Toast.LENGTH_LONG).show();return;}
        Intent i=new Intent(this,FlyOverlayService.class);
        if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
        Toast.makeText(this,"Муха выпущена 🪰",Toast.LENGTH_SHORT).show();
    }
}
