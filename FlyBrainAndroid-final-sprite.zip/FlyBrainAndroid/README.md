# Муха — Mini Fly Brain
Android overlay pet with a compact LIF neural model inspired by Drosophila circuits.

Permissions:
- Display over other apps: required for the fly to crawl over the launcher/apps.
- Notifications: for the foreground service notification.
- Vibration: tactile response on touch.

No contacts, messages, photos, microphone, camera, location, or files are requested.
