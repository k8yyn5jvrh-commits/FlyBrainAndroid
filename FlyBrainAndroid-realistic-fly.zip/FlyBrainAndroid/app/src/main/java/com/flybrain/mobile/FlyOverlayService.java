package com.flybrain.mobile;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.*;
import android.os.*;
import android.view.*;
import java.util.*;

public class FlyOverlayService extends Service implements SensorEventListener {
    private WindowManager wm; private FlyView view; private WindowManager.LayoutParams lp;
    private final Handler h=new Handler(Looper.getMainLooper()); private final Brain brain=new Brain();
    private SensorManager sm; private float shake=0f, touchReward=0f, battery=.5f; private long last=0, bornMs;
    private float vx=2.1f,vy=1.3f; private final Random rnd=new Random();

    @Override public void onCreate(){super.onCreate();
        createChannel(); startForeground(11,notification());
        wm=(WindowManager)getSystemService(WINDOW_SERVICE); sm=(SensorManager)getSystemService(SENSOR_SERVICE);
        Sensor a=sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER); if(a!=null)sm.registerListener(this,a,SensorManager.SENSOR_DELAY_GAME);
        Intent bi=registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED)); if(bi!=null){int l=bi.getIntExtra("level",50),s=bi.getIntExtra("scale",100);battery=s>0?(float)l/s:.5f;}
        android.content.SharedPreferences p=getSharedPreferences("brain",MODE_PRIVATE); brain.memory=p.getFloat("memory",.35f);brain.curiosity=p.getFloat("curiosity",.45f);brain.energy=p.getFloat("energy",.7f);bornMs=p.getLong("born",System.currentTimeMillis()); if(!p.contains("born")){bornMs=System.currentTimeMillis();p.edit().putLong("born",bornMs).apply();}
        addFly(); last=System.nanoTime(); h.post(loop);
    }
    private void addFly(){
        view=new FlyView(this);
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        lp=new WindowManager.LayoutParams(112,112,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.START;lp.x=120;lp.y=300;wm.addView(view,lp);
    }
    private final Runnable loop=new Runnable(){public void run(){
        long now=System.nanoTime();float dt=Math.min(.05f,(now-last)/1_000_000_000f);last=now;
        Calendar c=Calendar.getInstance();float circ=(float)(.5+.5*Math.cos((c.get(Calendar.HOUR_OF_DAY)-14)/24.0*Math.PI*2));
        brain.step(Math.min(1f,shake/8f),touchReward,battery,circ,dt);shake*=.86f;touchReward*=.90f;
        if(brain.escape>.12f){vx+=(rnd.nextFloat()-.5f)*12f;vy+=(rnd.nextFloat()-.5f)*12f;}
        else {vx+=(rnd.nextFloat()-.5f)*.6f+(brain.turn-.05f)*.4f;vy+=(rnd.nextFloat()-.5f)*.6f;}
        float speed=(2f+brain.forward*18f+brain.escape*30f)*(0.7f+brain.energy*.6f);float mag=(float)Math.hypot(vx,vy);if(mag>speed){vx=vx/mag*speed;vy=vy/mag*speed;}
        lp.x+=(int)vx;lp.y+=(int)vy;
        Point sz=new Point();wm.getDefaultDisplay().getSize(sz);int maxX=Math.max(0,sz.x-lp.width),maxY=Math.max(0,sz.y-lp.height-80);
        if(lp.x<0){lp.x=0;vx=Math.abs(vx);}if(lp.x>maxX){lp.x=maxX;vx=-Math.abs(vx);}if(lp.y<0){lp.y=0;vy=Math.abs(vy);}if(lp.y>maxY){lp.y=maxY;vy=-Math.abs(vy);}
        try{wm.updateViewLayout(view,lp);}catch(Exception ignored){} view.invalidate();
        h.postDelayed(this,33);
    }};
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){h.removeCallbacks(loop);if(sm!=null)sm.unregisterListener(this);if(view!=null)try{wm.removeView(view);}catch(Exception ignored){}getSharedPreferences("brain",MODE_PRIVATE).edit().putFloat("memory",brain.memory).putFloat("curiosity",brain.curiosity).putFloat("energy",brain.energy).apply();super.onDestroy();}
    @Override public void onSensorChanged(SensorEvent e){if(e.sensor.getType()==Sensor.TYPE_ACCELEROMETER){float m=(float)Math.sqrt(e.values[0]*e.values[0]+e.values[1]*e.values[1]+e.values[2]*e.values[2]);shake=Math.max(shake,Math.abs(m-9.81f));vx+=e.values[0]*-.02f;vy+=e.values[1]*.02f;}}
    @Override public void onAccuracyChanged(Sensor s,int a){}
    @Override public android.os.IBinder onBind(Intent i){return null;}

    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel("flybrain","Муха",NotificationManager.IMPORTANCE_LOW);ch.setDescription("Муха живёт поверх экрана");getSystemService(NotificationManager.class).createNotificationChannel(ch);}}
    private Notification notification(){Intent i=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);return new Notification.Builder(this,"flybrain").setContentTitle("🪰 Муха живёт").setContentText("Mini Fly Brain активен").setSmallIcon(android.R.drawable.ic_menu_compass).setContentIntent(pi).setOngoing(true).build();}

    private class FlyView extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); long down;
        FlyView(Context c){super(c);setBackgroundColor(Color.TRANSPARENT);p.setStrokeCap(Paint.Cap.ROUND);}

        @Override protected void onDraw(Canvas c){
            super.onDraw(c);

            float cx=getWidth()/2f, cy=getHeight()/2f;
            float angle=(float)Math.toDegrees(Math.atan2(vy,vx));

            // Keep the same 112x112 overlay size, but draw a more fly-like body.
            c.save();
            c.rotate(angle,cx,cy);

            float t=android.os.SystemClock.uptimeMillis()/1000f;
            float move=Math.min(1f,(float)Math.hypot(vx,vy)/12f);
            float wing=(float)Math.sin(t*(18f+move*18f))*7f;
            float leg=(float)Math.sin(t*(9f+move*10f))*4f;

            // Soft shadow.
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(55,0,0,0));
            c.drawOval(cx-31,cy+22,cx+32,cy+34,p);

            // Wings: translucent, outlined, animated.
            p.setColor(Color.argb(105,218,232,238));
            c.save();
            c.rotate(-33f-wing,cx-7,cy-8);
            c.drawOval(cx-39,cy-28,cx-2,cy+1,p);
            c.restore();

            c.save();
            c.rotate(33f+wing,cx-7,cy+8);
            c.drawOval(cx-39,cy-1,cx-2,cy+28,p);
            c.restore();

            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.7f);
            p.setColor(Color.argb(145,150,172,180));
            c.save();
            c.rotate(-33f-wing,cx-7,cy-8);
            c.drawOval(cx-39,cy-28,cx-2,cy+1,p);
            c.drawLine(cx-31,cy-17,cx-7,cy-6,p);
            c.restore();
            c.save();
            c.rotate(33f+wing,cx-7,cy+8);
            c.drawOval(cx-39,cy-1,cx-2,cy+28,p);
            c.drawLine(cx-31,cy+17,cx-7,cy+6,p);
            c.restore();

            // Six articulated legs.
            p.setStrokeWidth(3.0f);
            p.setColor(Color.rgb(28,31,30));
            float[] ys={-15f,0f,15f};
            for(int i=0;i<3;i++){
                float y=cy+ys[i];
                float swing=(i==1?-leg:leg);
                c.drawLine(cx-6,y,cx-25,y-8+swing,p);
                c.drawLine(cx-25,y-8+swing,cx-39,y-3+swing,p);
                c.drawLine(cx+1,y,cx+22,y-8-swing,p);
                c.drawLine(cx+22,y-8-swing,cx+38,y-2-swing,p);
            }

            // Abdomen.
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(24,27,27));
            c.drawOval(cx-3,cy-19,cx+31,cy+19,p);

            // Abdomen segmentation.
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2f);
            p.setColor(Color.rgb(69,74,70));
            c.drawArc(cx+6,cy-18,cx+18,cy+18,88,184,false,p);
            c.drawArc(cx+15,cy-16,cx+27,cy+16,88,184,false,p);

            // Thorax.
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(42,47,45));
            c.drawOval(cx-16,cy-22,cx+9,cy+22,p);

            // Tiny hairs on thorax/abdomen.
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.2f);
            p.setColor(Color.argb(170,95,101,96));
            for(int i=-2;i<=2;i++){
                c.drawLine(cx-5,cy+i*6,cx-11,cy+i*7-3,p);
                c.drawLine(cx+14,cy+i*5,cx+20,cy+i*6-3,p);
            }

            // Head.
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(37,42,40));
            c.drawOval(cx-27,cy-17,cx-9,cy+17,p);

            // Compound eyes.
            p.setColor(Color.rgb(142,32,38));
            c.drawOval(cx-29,cy-14,cx-20,cy-2,p);
            c.drawOval(cx-29,cy+2,cx-20,cy+14,p);
            p.setColor(Color.argb(145,255,120,120));
            c.drawCircle(cx-25.5f,cy-9,1.6f,p);
            c.drawCircle(cx-25.5f,cy+7,1.6f,p);

            // Antennae.
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.8f);
            p.setColor(Color.rgb(38,42,40));
            c.drawLine(cx-25,cy-7,cx-36,cy-15,p);
            c.drawLine(cx-25,cy+7,cx-36,cy+15,p);
            c.drawLine(cx-36,cy-15,cx-42,cy-17,p);
            c.drawLine(cx-36,cy+15,cx-42,cy+17,p);

            // Small state glow: subtle, not replacing the fly itself.
            if(brain.escape>.12f){
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2.2f);
                p.setColor(Color.argb(150,255,80,80));
                c.drawOval(cx-34,cy-27,cx+35,cy+27,p);
            }

            c.restore();
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_DOWN){
                down=System.currentTimeMillis();
                touchReward=1f;
                vx+=(rnd.nextFloat()-.5f)*8;
                vy+=(rnd.nextFloat()-.5f)*8;
                try{
                    ((android.os.Vibrator)getSystemService(VIBRATOR_SERVICE))
                        .vibrate(android.os.VibrationEffect.createOneShot(24,70));
                }catch(Exception ignored){}
                return true;
            }
            return true;
        }
    }

}